INSERT INTO company (id, company_name) VALUES(1, 'EBS');

INSERT INTO company (id, company_name) VALUES(2, 'MICROSOFT');

INSERT INTO employee (id, name,sur_name,email,address,salary,company_id) VALUES(1, 'John','Max','meetjibin@gmail.com','Ackerstrasse 19 40223 Dusseldorf',60000,1);
INSERT INTO employee (id, name,sur_name,email,address,salary,company_id) VALUES(2, 'Jean','A','abc@gmail.com','xyz Cologne',62000,2);